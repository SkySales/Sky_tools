import socket
import time
import requests

def trace():
    dom = input('Enter a Domain to Trace Route: ')
    print('Tracing Route for Domain ' + dom)
    time.sleep(3)
    try:
        print('TraceRoute Success\nResult: ' + socket.gethostbyname(dom))
    except:
        print('Insert the Correct Domain!')
    time.sleep(2)
    start()

def start():
    print('#######################################################################################')
    print('######|WELCOME TO SKY MULTI TOOL (v.1) [ADDED MORE FEATURES SOON]|######################')
    print('##################|CREATED: 10/23/2021|#################################################')
    print('############|PLEASE BE GOOD AND USE THIS FOR GOOD|######################################')
    print('#######################################################################################')
    comm = input('Please choose a features >\nType "trace" for Domain TraceRoute\nType "lookup" for IP Lookup Details\nEnter Here: ')
    if comm == "trace":
        trace()
    elif comm == "lookup":
        lookup()

def lookup():
    ip = input('Enter IP to Lookup details: ')
    time.sleep(2)
    try:
        response = requests.post("http://ip-api.com/batch", json=[
            {"query": ip}
        ]).json()

        for ip in response:
            print("ORG: " + ip['org'])
            print("IP: " + ip['query'])
            print("ISP: " + ip['isp'])
            print("Country: " + ip['country'])
            print("City: " + ip['city'])
            print("Zip Code: " + ip['zip'])
            print("AS: " + ip['as'])
            print("RegionName: " + ip['regionName'])
            print("TimeZone: " + ip['timezone'])
    except:
        print('Enter the Correct IP!')
    time.sleep(2)
    start()
def welcome():
    user = input('Enter Your Name :) : ')
    user_check = input('Confirm Your Name: ')

    if user_check == user:
        print('Welcome Sayo Tropa HAHAHA maging mabuting tao ahh!!')
        comm = input('Press [C] to Continue Enjoy!')
        if comm == "C" or comm == "c":
            start()
    else:
        print('Pangalan nlng mamaliin mo pa HAHAHA Ulitin mo!')
        welcome()

welcome()